import 'package:flutter/material.dart';

import 'genrate.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          flexibleSpace: AppBar(
            flexibleSpace: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const TabBar(
                  tabs: [
                    Tab(
                      text: "Hall",
                    ),
                    Tab(
                      text: "Dining",
                    ),
                    Tab(
                      text: "Bathroom",
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            GridViewPage(
              listofdata: listdata,
            ),
            Center(
              child: Text("Dining"),
            ),
            Center(
              child: Text("Bathroom"),
            )
          ],
        ),
      ),
    );
  }
}

List<Devicedata> listdata = [
  Devicedata(
    heading1: "Light",
    heading2: "tube light",
    status: true,
  ),
  Devicedata(
    heading1: "Fan",
    heading2: "hall Strip",
    status: false,
  ),
  Devicedata(
    heading1: "RGB",
    heading2: "d-light",
    status: false,
  ),
  Devicedata(
    heading1: "Light",
    heading2: "tube ",
    status: false,
  ),
];

class Devicedata {
  String? heading1;
  String? heading2;
  bool? status;

  Devicedata({
    this.heading1,
    this.heading2,
    this.status,
  });
}
