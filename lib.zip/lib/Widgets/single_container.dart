import 'package:flutter/material.dart';

import '../homepage.dart';

class SingleContainer extends StatelessWidget {
  bool? statusofbulb;
  Devicedata? singledevicedata;
  ValueChanged<bool>? onStatuschanged;

  SingleContainer(
      {Key? key,
      this.statusofbulb,
      this.singledevicedata,
      this.onStatuschanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      color: Colors.lightBlue,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "${singledevicedata!.heading1}",
                      style: Theme.of(context).textTheme.headline5,
                    ),
                    Text(
                      "${singledevicedata!.heading2}",
                      style: Theme.of(context).textTheme.headline6,
                    )
                  ],
                ),
                Expanded(child: Container()),
                Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.white,
                    ),
                    child: const Icon(Icons.check)),
                Expanded(child: Container()),
              ],
            ),
            Expanded(child: Container()),
            Row(
              children: [
                Text(statusofbulb! ? "ON" : "OFF"),
                Expanded(child: Container()),
                Switch(
                  activeColor: Colors.white,
                  value: statusofbulb!,
                  onChanged: (value) {
                    onStatuschanged!(value);
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
