import 'package:flutter/material.dart';
import 'package:fluttertest/homepage.dart';

import 'Widgets/single_container.dart';

class GridViewPage extends StatefulWidget {
  List<Devicedata>? listofdata;

  GridViewPage({Key? key, this.listofdata}) : super(key: key);

  @override
  State<GridViewPage> createState() => _GridViewPageState();
}

class _GridViewPageState extends State<GridViewPage> {
  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      padding: const EdgeInsets.all(10),
      // Generate 100 widgets that display their index in the List.
      children: List.generate(widget.listofdata!.length, (index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Center(
              child: SingleContainer(
            statusofbulb: widget.listofdata![index].status,
            singledevicedata: widget.listofdata![index],
            onStatuschanged: (value) {
              setState(() {
                widget.listofdata![index].status = value;
              });
            },
          )),
        );
      }),
    );
  }
}
